import {describe, expect, test} from '@jest/globals';

describe('Censorship function should call aws rekognition API', () => {
    
});